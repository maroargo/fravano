export interface IStatus {  
    id: string  
    name: string
  }