export interface IUserNav {  
  name?: string  
  email?: string
}

export interface IRolNav {  
  name: string  
  plan: string
  logo: string
}