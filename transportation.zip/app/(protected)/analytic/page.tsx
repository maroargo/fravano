export default async function Analytic() {
    
  return (
    <>
      <iframe title="TRANSPORTATION APP" width="1140" height="541.25" 
        src="https://app.powerbi.com/reportEmbed?reportId=96537384-f80f-4e02-9a69-7362673d98f2&autoAuth=true&ctid=62481a46-4946-41f5-af46-76afeb29a49c"></iframe>
    </>  
    
  );  
}